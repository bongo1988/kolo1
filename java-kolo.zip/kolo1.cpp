
#include <iostream>

using namespace std;

void pytanie() {
  cout<<"Q1) Jak wyswietlic roznice miedzy drugim a trzecim zatwierdzeniem wykonanym w galezi master?"<<endl;
  cout<<"A1) ..."<<endl;
  cout<<"Q2) Co sie zmienilo?"<<endl;
  cout<<"A2) ..."<<endl;
}

int main(int argc, char **argv) {
  pytanie();
  return 0;
}

