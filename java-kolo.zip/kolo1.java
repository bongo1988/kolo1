

class Kolo1 {
  static void pytanie() {
    System.out.println("Q1) Jak wyswietlic roznice miedzy drugim a trzecim zatwierdzeniem wykonanym w galezi master?");
    System.out.println("A1) ...");
    System.out.println("Q2) Co sie zmienilo?");
    System.out.println("A2) ...");
  }

  public static void main(String[] args) {
    pytanie();
  }

}

